Okay, so I have a confession:
     this was the first font I ever made.

It was really easy, not like the stuff I'm working on now, which is really hard and time consuming. But I got familiar with Fontographer, and I do think Hammerkeys is kind of interesting.

Hammerkeys is freeware, but not public domain. Plaguarism or other such stupidity will be dealt with by my roommate and one of his AK-47s (you think I'm kidding, don't you?).

If you want to mass-distribute it, keep the archive file intact, and send me a copy of the disc. Email me for my current physical whereabouts.

More fonts will be added sporadically. If you want to be on MFactor's update list, send me an email with the subject of "Add Announce".

Matt Lyon, matt@mfactor.com
http://www.mfactor.com